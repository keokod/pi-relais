let head = `
<link rel="stylesheet" href="css.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">`;


document.addEventListener('DOMContentLoaded', (e) => {
    var x = document.getElementsByTagName("head");
    console.log(x[0]);
})

